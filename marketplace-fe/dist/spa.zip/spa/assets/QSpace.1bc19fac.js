import{s as a,j as e}from"./index.1dbfdf49.js";const s=a("div",{class:"q-space"});var c=e({name:"QSpace",setup(){return()=>s}});export{c as Q};
