import{k as a,am as r}from"./index.1dbfdf49.js";function u(){return a(r)}export{u};
