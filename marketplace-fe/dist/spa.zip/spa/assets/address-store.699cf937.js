import{an as r}from"./index.1dbfdf49.js";import{server as e}from"./axios.74414804.js";const t=r("address",{actions:{async all(){return await e.get("api/address")}}});export{t as u};
